﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RestaurentManagementBusinessLayer
    {
    public interface IBigBazarBL
        {
        public Staff AddStaffBL();
        }
    }
